
#ifndef _DISPLAY_EPD_W21_H_
#define _DISPLAY_EPD_W21_H_

#define EPD_W21_WRITE_DATA 1
#define EPD_W21_WRITE_CMD  0

extern void driver_delay_us(unsigned int xus);
extern void driver_delay_xms(unsigned long xms);
extern void EPD_W21_Init(void);

extern void EPD_display_init(void);//EPD init 
extern void full_display(void pic_display(void)); //full  display
void partial_display(unsigned int x,unsigned int y,unsigned int w,unsigned int l ,void partial_old(void),void partial_new(void)); //partial display
extern void lut(void);
extern void lut1(void);
extern void lcd_chkstatus(void);
extern void deep_sleep(void); //Enter deep sleep mode
// full display
extern void pic_display_white(void);
extern void pic_display1(void);
extern void pic_display2(void);
//partial display
extern void partial_full00(void);
extern void partial_full01(void);
extern void partial_full02(void);
extern void partial_full03(void);
extern void partial_full04(void);
extern void partial_full05(void);
extern void partial00(void);
extern void partial01(void);
extern void partial02(void);
extern void partial03(void);
extern void partial04(void);
extern void partial05(void);
extern void partial06(void);
extern void partial07(void);
extern void partial08(void);
extern void partial09(void);

#endif
/***********************************************************
						end file
***********************************************************/


