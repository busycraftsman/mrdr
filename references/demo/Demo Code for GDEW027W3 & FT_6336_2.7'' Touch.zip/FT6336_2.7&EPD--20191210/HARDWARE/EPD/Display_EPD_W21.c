#include "delay.h"
#include "Display_EPD_W21_spi.h"
#include "Display_EPD_W21.h"
#include "Ap_29demo.h"	


void EPD_W21_Init(void)
{

	EPD_W21_RST_0;		// Module reset
	delay_ms(10);
	EPD_W21_RST_1;
	delay_ms(10);
	

}


 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////extern function/////////////////////////////////////////////////////////////////////////////////////////////////////////////

/***************** full screen display picture*************************/
void pic_display_white(void)
{
	unsigned int i;
		EPD_W21_WriteCMD(0x10);
		for(i=0;i<5808;i++)	     
		{
				EPD_W21_WriteDATA(0xff);  
		}  
		//driver_delay_xms(2);

		EPD_W21_WriteCMD(0x13);
		for(i=0;i<5808;i++)	     
		{
				EPD_W21_WriteDATA(0xff);  
		}  
		//driver_delay_xms(2);		 
}
void pic_display1(void)
{
	unsigned int i;
		EPD_W21_WriteCMD(0x10);
		for(i=0;i<5808;i++)	     
		{
				EPD_W21_WriteDATA(0xff);  
		}  
		//driver_delay_xms(2);

		EPD_W21_WriteCMD(0x13);
		for(i=0;i<5808;i++)	     
		{
				EPD_W21_WriteDATA(gImage_1[i]);  
		}  
		//driver_delay_xms(2);	 	 
}

void pic_display2(void)
{
	unsigned int i;
	EPD_W21_WriteCMD(0x10);
	for(i=0;i<5808;i++)	     
	{
		EPD_W21_WriteDATA(0xff);  
	}  

	EPD_W21_WriteCMD(0x13);	  	
	for(i=0;i<5808;i++)	     
	{
   EPD_W21_WriteDATA(gImage_2[i]);  

	}  
}


/***************** partial full screen display picture*************************/
void partial_full00(void)
{
	unsigned int i;
	for(i=0;i<5808;i++)	     
	{
			EPD_W21_WriteDATA(0x00);  
	}  
}
void partial_full01(void)
{
	unsigned int i;
	for(i=0;i<5808;i++)	     
	{
			EPD_W21_WriteDATA(~gImage_1[i]);  
	}  
}
void partial_full02(void)
{
	unsigned int i;
	for(i=0;i<5808;i++)	     
	{
			EPD_W21_WriteDATA(~gImage_2[i]);  
	}  
}
void partial_full03(void)
{   
	unsigned int i;
	for(i=0;i<5808;i++)	     
	{
			EPD_W21_WriteDATA(~gImage_3[i]);  
	}  
}

/***************** partial display 0~9 picture*************************/
void partial00(void)
{
	unsigned int i;
	for(i=0;i<256;i++)	     
	{
			EPD_W21_WriteDATA(0x00);  
	}  
}

void partial01(void)
{
	unsigned int i;

		for(i=0;i<256;i++)	     
			{
			EPD_W21_WriteDATA (~gImage_num1[i]);
			driver_delay_xms(2);  
			}	
	}
void partial02(void)
{
  unsigned int i;
		for(i=0;i<256;i++)	     
			{
			EPD_W21_WriteDATA (~gImage_num2[i]);
			driver_delay_xms(2);  
			}	
	}
void partial03(void)
{
	  unsigned int i;
		for(i=0;i<256;i++)	     
			{
			EPD_W21_WriteDATA (~gImage_num3[i]);
			driver_delay_xms(2);  
			}	
	}
void partial04(void)
{
	  unsigned int i;
		for(i=0;i<256;i++)	     
			{
			EPD_W21_WriteDATA (~gImage_num4[i]);
			driver_delay_xms(2);  
			}	
	}
void partial05(void)
{
	  unsigned int i;
		for(i=0;i<256;i++)	     
			{
			EPD_W21_WriteDATA (~gImage_num5[i]);
			driver_delay_xms(2);  
			}	
	}
void partial06(void)
{
	  unsigned int i;
		for(i=0;i<256;i++)	     
			{
			EPD_W21_WriteDATA (~gImage_num6[i]);
			driver_delay_xms(2);  
			}	
	}
void partial07(void)
{
	  unsigned int i;
		for(i=0;i<256;i++)	     
			{
			EPD_W21_WriteDATA (~gImage_num7[i]);
			driver_delay_xms(2);  
			}	
	}
void partial08(void)
{
	  unsigned int i;
		for(i=0;i<256;i++)	     
			{
			EPD_W21_WriteDATA (~gImage_num8[i]);
			driver_delay_xms(2);  
			}	
	}
void partial09(void)
{
	  unsigned int i;
		for(i=0;i<256;i++)	     
			{
			EPD_W21_WriteDATA (~gImage_num9[i]);
			driver_delay_xms(2);  
			}	
	}
/*************************EPD display init function******************************************************/
//LUT download
void lut(void)
{
	unsigned int count;
	EPD_W21_WriteCMD(0x20);
	for(count=0;count<44;count++)	     
		{EPD_W21_WriteDATA(lut_vcomDC[count]);}

	EPD_W21_WriteCMD(0x21);
	for(count=0;count<42;count++)	     
		{EPD_W21_WriteDATA(lut_ww[count]);}   
	
	EPD_W21_WriteCMD(0x22);
	for(count=0;count<42;count++)	     
		{EPD_W21_WriteDATA(lut_bw[count]);} 

	EPD_W21_WriteCMD(0x23);
	for(count=0;count<42;count++)	     
		{EPD_W21_WriteDATA(lut_wb[count]);} 

	EPD_W21_WriteCMD(0x24);
	for(count=0;count<42;count++)	     
		{EPD_W21_WriteDATA(lut_bb[count]);} 
}

void lut1(void)
{
	unsigned int count;
	EPD_W21_WriteCMD(0x20);
	for(count=0;count<44;count++)	     
		{EPD_W21_WriteDATA(lut_vcom1[count]);}

	EPD_W21_WriteCMD(0x21);
	for(count=0;count<42;count++)	     
		{EPD_W21_WriteDATA(lut_ww1[count]);}   
	
	EPD_W21_WriteCMD(0x22);
	for(count=0;count<42;count++)	     
		{EPD_W21_WriteDATA(lut_bw1[count]);} 

	EPD_W21_WriteCMD(0x23);
	for(count=0;count<42;count++)	     
		{EPD_W21_WriteDATA(lut_wb1[count]);} 

	EPD_W21_WriteCMD(0x24);
	for(count=0;count<42;count++)	     
		{EPD_W21_WriteDATA(lut_bb1[count]);}   
}

//Detection busy

void lcd_chkstatus(void)
{
	unsigned char busy;
	do
	{
		EPD_W21_WriteCMD(0x71);
		busy = isEPD_W21_BUSY;
		busy =!(busy & 0x01);        
	}
	while(busy);   
	                   
}	

void EPD_display_init(void)
{
	  unsigned char HRES_byte1=0x00;			//176
	  unsigned char HRES_byte2=0xb0;
	  unsigned char VRES_byte1=0x01;			//264
	  unsigned char VRES_byte2=0x08;
    EPD_W21_Init();
		EPD_W21_WriteCMD(0x01); 		 //POWER SETTING 
		EPD_W21_WriteDATA (0x03);	     
		EPD_W21_WriteDATA (0x00);
		EPD_W21_WriteDATA (0x2b);
		EPD_W21_WriteDATA (0x2b);

		EPD_W21_WriteCMD(0x06);         //boost�趨
		EPD_W21_WriteDATA (0x07);   //A    
		EPD_W21_WriteDATA (0x07);   //B
		EPD_W21_WriteDATA (0x17);   //C  
		
		EPD_W21_WriteCMD(0x16);
		EPD_W21_WriteDATA(0x00);	

	  EPD_W21_WriteCMD(0x04);
	  delay_ms(300);
		//lcd_chkstatus();

		EPD_W21_WriteCMD(0x00);     //panel setting
		EPD_W21_WriteDATA(0xbf);		//KW-BF   KWR-AF	BWROTP 0f

		EPD_W21_WriteCMD(0x30);			//PLL setting
		EPD_W21_WriteDATA (0x3a);   //90 50HZ  3A 100HZ   29 150Hz 39 200HZ	31 171HZ

		EPD_W21_WriteCMD(0x61);			//resolution setting
		EPD_W21_WriteDATA (HRES_byte1);
		EPD_W21_WriteDATA (HRES_byte2);    //176 	 
		EPD_W21_WriteDATA (VRES_byte1);		
		EPD_W21_WriteDATA (VRES_byte2);		//264

		EPD_W21_WriteCMD(0x82);				//vcom_DC setting
		EPD_W21_WriteDATA (0x28);			//0x28:-2.0V,0x12:-0.9V		
		driver_delay_xms(2);	 
		EPD_W21_WriteCMD(0X50);			//VCOM AND DATA INTERVAL SETTING			
		EPD_W21_WriteDATA(0x97);		//WBmode:VBDF 17|D7 VBDW 97 VBDB 57		WBRmode:VBDF F7 VBDW 77 VBDB 37  VBDR B7}
	}
/***************************full display function*************************************/
void full_display(void pic_display(void))
{

		lut(); //Power settings
		pic_display(); //picture
		EPD_W21_WriteCMD(0x12);			//DISPLAY REFRESH 	
		driver_delay_xms(100);	    //!!!The delay here is necessary, 200uS at least!!!     
		//lcd_chkstatus();
	  delay_ms(1000); //��ʱʱ���ˢ��ʱ��Ҫ��Ӧ������border�߻�ƫ�ڡ�
	  delay_ms(1000);
	  delay_ms(500);
}

/***************************partial display function*************************************/

void partial_display(unsigned int x,unsigned int y,unsigned int w,unsigned int l ,void partial_old(void),void partial_new(void)) //partial display{
{		
    EPD_W21_WriteCMD(0x82);			//vcom_DC setting  	
    EPD_W21_WriteDATA (0x08);	
		EPD_W21_WriteCMD(0X50);
		EPD_W21_WriteDATA(0x47);		
		lut1();	
	  EPD_W21_WriteCMD(0x91);		//This command makes the display enter partial mode
		EPD_W21_WriteCMD(0x90);		//resolution setting
	
    EPD_W21_WriteCMD(0x14); //write old data
		EPD_W21_WriteDATA(0);	    //x-start
		EPD_W21_WriteDATA(x);     //x-end
		EPD_W21_WriteDATA(0);	    //y-start
		EPD_W21_WriteDATA(y);	    //y-end
		EPD_W21_WriteDATA(0);	    //w-start
		EPD_W21_WriteDATA(w);	    //w-end
		EPD_W21_WriteDATA(0);	    //l-start
		EPD_W21_WriteDATA(l);	    //l-end
		partial_old();

    EPD_W21_WriteCMD(0x15); //write new data
		EPD_W21_WriteDATA(0);	    //x-start
		EPD_W21_WriteDATA(x);     //x-end
		EPD_W21_WriteDATA(0);	    //y-start
		EPD_W21_WriteDATA(y);	    //y-end
		EPD_W21_WriteDATA(0);	    //w-start
		EPD_W21_WriteDATA(w);	    //w-end
		EPD_W21_WriteDATA(0);	    //l-start
		EPD_W21_WriteDATA(l);	    //l-end
		partial_new();

    EPD_W21_WriteCMD(0x16); //write display position
		EPD_W21_WriteDATA(0);	    //x-start
		EPD_W21_WriteDATA(x);     //x-end
		EPD_W21_WriteDATA(0);	    //y-start
		EPD_W21_WriteDATA(y);	    //y-end
		EPD_W21_WriteDATA(0);	    //w-start
		EPD_W21_WriteDATA(w);	    //w-end
		EPD_W21_WriteDATA(0);	    //l-start
		EPD_W21_WriteDATA(l);	    //l-end
	 // lcd_chkstatus();
	}
/////////////////////////////Enter deep sleep mode////////////////////////
void deep_sleep(void) //Enter deep sleep mode
{
		EPD_W21_WriteCMD(0X50);
		EPD_W21_WriteDATA(0xf7);	
		EPD_W21_WriteCMD(0X02);  	//power off
  	//lcd_chkstatus();
	  delay_ms(100);
		EPD_W21_WriteCMD(0X07);  	//deep sleep
		EPD_W21_WriteDATA(0xA5);
}




/***********************************************************
						end file
***********************************************************/

